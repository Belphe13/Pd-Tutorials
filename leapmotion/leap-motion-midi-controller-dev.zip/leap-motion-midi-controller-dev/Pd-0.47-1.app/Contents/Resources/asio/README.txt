

In order to build ASIO support into Pd on Windows, you need to download the
ASIO sources from Steinberg directly.  Their license does not let us
redistribute their source files.

- Download the ASIO SDK http://www.steinberg.net/en/company/3rd_party_developer.html
 You have to agree to Steinberg's license, then submit an email address, then
 they'll send you the download URL in an email. 

- Uncompress asiosdk2.2.zip into pd/asio


